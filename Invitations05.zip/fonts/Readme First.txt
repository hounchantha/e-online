This DEMO font is not contain all of its unicode glyphs, and for PERSONAL USE ONLY.

===================================================

Get the FULL VERSION and COMMERCIAL LICENSE here:
https://creativemarket.com/goodjava?u=goodjava

Paypal account for donation : https://paypal.me/goodjava

===================================================

NOTE:
- If there is a problem, question, or anything about my fonts, please sent an email to:
goodjavastudio@gmail.com



- Available for Extended License. Contact us by email!

- Share your work with this font and tag us on instagram @good_java

================

Thanks,

Good Java Studio